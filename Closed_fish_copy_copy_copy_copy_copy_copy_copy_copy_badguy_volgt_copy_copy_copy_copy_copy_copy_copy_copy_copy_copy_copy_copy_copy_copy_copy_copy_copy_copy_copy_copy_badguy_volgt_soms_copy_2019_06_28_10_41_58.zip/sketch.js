var myStorage = window.localStorage;
var pasthighscore = localStorage.getItem('bestscore');
var highscore = localStorage.getItem('bestscore');
var bg;
var losetext;
var wintext;
var beginbg;
var bullets = []
var specialbullets = []
var badbullets = []
var skybadbullets = []
var wallbadbullets = []
var specialbulletaccept = true
var maxBullets = 60;
var maxSpecialBullets = 3;
var specialReload = true;
var badguymoving = false;
var playerdisable = true;
var win = false;
var shootdisable = false;
var second;
var badguyattacknumber = 1;
var beginschermerzijn = true;
var procent;
class Player{
  constructor(){
    this.xPos = width/2
    this.yPos = height/2
    this.radius = 10
    this.xSpeed = 0
    this.ySpeed = 0
    this.jetfuel = 180
    this.health = 1
  }

  move(){
    if (keyIsDown(65)) {
		this.xSpeed -= 3;
	}

	if (keyIsDown(68)) {
		this.xSpeed += 3;
	}

    this.xPos += this.xSpeed
    this.xSpeed = 0
    this.yPos += this.ySpeed
    this.ySpeed += 0.2
    if (keyIsDown(16) && this.jetfuel > 1){
      this.ySpeed -= 0.65
      this.jetfuel -= 17
    }
    if (this.jetfuel < 180){
      this.jetfuel += 4
    }
    if (keyIsDown(32) && this.yPos == height - 10){
      this.ySpeed = -7
    }
    if (this.xPos > width-10) {
		this.xPos = width-10
	}
	if (this.xPos < 10) {
		this.xPos = 10
	}
	if (this.yPos > height-10) {
		this.yPos = height-10
      this.ySpeed = 0;
	}
	if (this.yPos < 10) {
		this.yPos = 10
        this.ySpeed = 0
	}
    
  }
  
  damagecheck(badbullet, badguy){
    var pdx = badbullet.xPos - this.xPos;
	var pdy = badbullet.yPos - this.yPos;
    var pdx2 = skybadbullets.xPos - this.xPos;
	var pdy2 = skybadbullets.yPos - this.yPos;
    var pdx3 = wallbadbullets.xPos - this.xPos;
    var pdy3 = wallbadbullets.yPos - this.yPos;
    // console.log("yeehaw")
	if (sqrt(pdx*pdx + pdy*pdy) <= this.radius || sqrt(pdx2*pdx2 + pdy2*pdy2) <= this.radius || sqrt(pdx3*pdx3 + pdy3*pdy3) <= this.radius){
      if (playerdisable == true){
        playerdisable = false;
        setInterval(badguygrow, 1)
      }
	}
  }
  
  badguydamagecheck(badguy){
    var pdx = badguy.xPos - this.xPos;
    var pdy = badguy.yPos - this.yPos;
	if (sqrt(pdx*pdx + pdy*pdy) <= this.radius + badguy.badguyradius){
      if (playerdisable == true){
        playerdisable = false;
        setInterval(badguygrow, 1)
      }
	}
  }
  
  exist(){
    if (playerdisable == true){
      fill(0, 219, 223)
      circle(this.xPos, this.yPos, this.radius)
      fill(255, 255, 255)
    }
  }
}

class Bullet{
  constructor(player, xSpeed){
    this.xPos = player.xPos
    this.yPos = player.yPos
    this.xSpeed = xSpeed
    this.ySpeed = 0
  } 
  move(){
    this.xPos += this.xSpeed
	this.yPos += this.ySpeed    
  }
  exist(){
    fill(0, 219, 223)
    ellipse(this.xPos, this.yPos, 5)
    fill(255, 255, 255)
  }
}

class specialBullet{
  constructor(player, xSpeed){
    this.xPos = player.xPos
    this.yPos = player.yPos
    this.xSpeed = xSpeed
    this.ySpeed = 0
  } 
  move(){
    this.xPos += this.xSpeed
	this.yPos += this.ySpeed    
  }
  exist(){
    fill(0, 219, 223)
    ellipse(this.xPos, this.yPos, 15)
    fill(255, 255, 255)
  }
}

class gauge{
  constructor(){
    this.backxPos = 20
    this.backyPos = 20
    this.fuelxPos = 22.5
    this.fuelyPos = 77.5
    this.fuelammount = player.jetfuel / 3.272727272727273
  }
  update(){
    this.fuelammount = player.jetfuel / 3.272727272727273
  }
  draw(){
    fill(200)
    rect(this.backxPos, this.backyPos, 30, 60)
    fill('red')
    rect(this.fuelxPos, this.fuelyPos, 25, -this.fuelammount)
    fill(255)
  }
}

class Badguy{
  constructor(){
   this.xPos = width;
   this.yPos = height/2;
   this.health = 1000;
   this.healthomgekeerd = 0;
   this.xSpeed = 0;
   this.ySpeed = 0;
   this.badguyradius = height/4;
   this.badguybeginradius = height/4;
  }
  damagecheck(bullet){
    var dx = bullet.xPos - this.xPos;
	var dy = bullet.yPos - this.yPos;
    // console.log("yeehaw")
	if (sqrt(dx*dx + dy*dy) <= this.badguyradius & win == false & playerdisable == true){
      console.log("damage taken")
      this.health = this.health-1;
      this.healthomgekeerd = this.healthomgekeerd+1;
      if (this.health > 300){
        this.badguyradius = this.badguyradius - this.badguybeginradius/1000;
      }
      bullet.yPos = 1000000000000000;
      if (this.health <= 0) {
        win = true;
        setInterval(badguyshrink, 1)
        if (second <= pasthighscore || pasthighscore == null){
          localStorage.setItem('bestscore', second);
        }
        else{
        }
        highscore = localStorage.getItem('bestscore');
      }
	}
  }
  
  move(){
    if (this.xPos <= -this.badguyradius){
      this.xSpeed = 0
      this.xPos = width
      this.ySpeed = 0
      this.yPos = height/2
    }
    if (win == false & playerdisable == true)
      this.xPos = this.xPos + this.xSpeed
      this.yPos = this.yPos + this.ySpeed
  }
  
  specialdamagecheck(specialbullet){
    var dx2 = specialbullet.xPos - this.xPos;
	var dy2 = specialbullet.yPos - this.yPos;
    // console.log("yeehaw")
	if (sqrt(dx2*dx2 + dy2*dy2) <= this.badguyradius & win == false & playerdisable == true){
      console.log("damage taken")
      this.health = this.health-30;
      this.healthomgekeerd = this.healthomgekeerd+30;
      if (this.health > 300){
        this.badguyradius = this.badguyradius - this.badguybeginradius/100/1.5;
      }
      specialbullet.yPos = 10000;
      if (this.health <= 0) {
        win = true;
        setInterval(badguyshrink, 1)
        if (second > pasthighscore){
        }
        else{
          localStorage.setItem('bestscore', second);
        }
        highscore = localStorage.getItem('bestscore');
      }
	}
  }
  
  procent(){
    if (badguy.health < 0){
      procent = 0;
    }
    else{
      procent = this.health/10;
    }
    textSize(20);
    fill(255, 255, 255);
    text(procent + '%', 70, 75);
  }
  
  exist(){
    fill(255, 0, 0)
    circle(this.xPos, this.yPos, this.badguyradius, this.badguyradius)
    fill(255, 255, 255)
  }
}

class Badbullet{
  constructor(){
    this.xPos = badguy.xPos;
    this.yPos = badguy.yPos;
    this.xSpeed = (player.xPos / 20) - (badguy.xPos / 20)
    this.ySpeed = (player.yPos / 20) - (badguy.yPos / 20)
  }
  move(){
    this.xPos += this.xSpeed
    this.yPos += this.ySpeed
  }
  exist(){
    fill(255, 0, 0)
    circle(this.xPos, this.yPos, 5, 5)
    fill(255, 255, 255)
  }
}

class Skybadbullet{
  constructor(){
    this.xPos = player.xPos;
    this.yPos = -10;
    this.xSpeed = 0;
    this.ySpeed = 10;
  }
  move(){
    this.xPos += this.xSpeed
    this.yPos += this.ySpeed
  }
  exist(){
    fill(255, 0, 0)
    circle(this.xPos, this.yPos, 5, 5)
    fill(255, 255, 255)
  }
}

class Wallbadbullet{
  constructor(y){
    this.xPos = width;
    this.yPos = y;
    this.xSpeed = -2;
    this.ySpeed = 0;
  }
  move(){
    this.xPos += this.xSpeed
    this.yPos += this.ySpeed
  }
  exist(){
    fill(255, 0, 0)
    circle(this.xPos, this.yPos, 5, 5)
    fill(255, 255, 255)
  }
}

function badguyRainfire(){
  skybadbullets[skybadbullets.length] = new Skybadbullet();
}

function badguyWallfire(){
  holeinwall = Math.floor(Math.random()*39)
  for (var i = 0; i < 39; i++) {
    if (Math.abs(i - holeinwall) > 4){
      wallbadbullets[wallbadbullets.length] = new Wallbadbullet(5+(height/39)*i);
    }
  }
}

function badguyFire(){
  if (playerdisable == true & win == false){
    shootdisable = true;
    if (badguyattacknumber == 8){
      setTimeout(badguyRainfire, 100);
      setTimeout(badguyRainfire, 200);
      setTimeout(badguyRainfire, 300);
      setTimeout(badguyRainfire, 400);
      setTimeout(badguyRainfire, 500);
      setTimeout(badguyRainfire, 600);
      setTimeout(badguyRainfire, 700);
      setTimeout(badguyRainfire, 800);
      setTimeout(badguyRainfire, 1000);
      badguyattacknumber += 1;
      if (badguy.healthomgekeerd >= 700){
        setTimeout(badguyFire, 2000 - 700);
      }
      else {
        setTimeout(badguyFire, 2000 - badguy.healthomgekeerd);
      }
    }
    else if(badguyattacknumber == 16){
      badguyWallfire();
      badguyattacknumber = 1;
      if (badguy.healthomgekeerd >= 700){
        setTimeout(badguyFire, 1000 - 700);
      }
      else {
        setTimeout(badguyFire, 1000 - badguy.healthomgekeerd);
      }
    }
    else{
      badbullets[badbullets.length] = new Badbullet();
      badguyattacknumber += 1;
      if (badguy.healthomgekeerd >= 700){
        setTimeout(badguyFire, 1000 - 700);
      }
      else {
        setTimeout(badguyFire, 1000 - badguy.healthomgekeerd);
      }
    }
  }
}

function badguygo(){
  //badguy.xSpeed = (player.xPos / 200) - (badguy.xPos / 200)
  //badguy.ySpeed = (player.yPos / 200) - (badguy.yPos / 200)
}

function badguygrow(){
  badguy.badguyradius = badguy.badguyradius + height/250;
}

function badguyshrink(){
  if (badguy.badguyradius <= 0.00000000000000000000000001){
    badguy.yPos = 999999999999999999999999999999
    badguy.xPos = 999999999999999999999999999999
  }
  else{
    badguy.badguyradius = badguy.badguyradius - height/250;
  }
}

function timer(){
  if (win == false & playerdisable == true){
    second = second + 1;
    setTimeout(timer, 1000);
  }
}

function bulletmeter(){
  if (maxBullets == 0){
    textSize(20);
    fill(255, 255, 255);
    text('Reloading...', 70, 35);
  }
  else{
    textSize(20);
    fill(255, 255, 255);
    text(maxBullets + '/60', 70, 35);
  }
}

function specialbulletmeter(){
  if (maxSpecialBullets == 0){
    textSize(20);
    fill(255, 255, 255);
    text('Reloading...', 70, 55);
  }
  else{
    textSize(20);
    fill(255, 255, 255);
    text(maxSpecialBullets + '/3', 70, 55);
  }
}

function shootwaittime(){
  maxBullets = 60;
}

function specialshootwaittime(){
  maxSpecialBullets = 3;
  specialReaload = true
}

function acceptspecial(){
  specialbulletaccept = true
}

function badguymovecheck(){
  if (badguymoving == false){
    badguymoving = true;
    setTimeout(badguymovecheck, 10000)
  }
  else if (badguymoving == true){
    badguymoving = false;
    console.log("doet het")
    setTimeout(badguymovecheck, 3000)
  }
}

function setup() {
  createCanvas(window.innerWidth, window.innerHeight);
  player = new Player();
  meter = new gauge();
  badguy = new Badguy();
  bullet = null;
  bg = loadImage("superdupercoolebackgroundvoorgame.jpg");
  beginbg = loadImage("ultrablob3.png");
  losetext = loadImage("youlose.png");
  wintext = loadImage("youwin.png");
  second = 0;
  procent = badguy.health/10;
}


function draw() {
  if (beginschermerzijn == true){
    background(beginbg);
    if (keyIsPressed === true) {
      beginschermerzijn = false;
      setTimeout(timer, 1000);
      setTimeout(badguyFire, 3000);
      setTimeout(badguymovecheck, 3000)
    }
  }
  else{
    background(bg);
    if (keyIsDown(74)){
      if (playerdisable == true & shootdisable == true){
        if (maxBullets <= 0){
          setTimeout(shootwaittime, 1000);
        }
        else{
          if (player.xPos < badguy.xPos){
            bullets[bullets.length] = new Bullet(player, 5);
          }
          else{
            bullets[bullets.length] = new Bullet(player, -5);
          }
          maxBullets -= 1;
        }
      }
    }
    if (keyIsDown(75)){
      if (playerdisable == true & shootdisable == true & specialbulletaccept == true & maxSpecialBullets == 3 || playerdisable == true & shootdisable == true & specialbulletaccept == true & maxSpecialBullets == 2 || playerdisable == true & shootdisable == true & specialbulletaccept == true & maxSpecialBullets == 1){
        if (player.xPos < badguy.xPos){
          specialbullets[specialbullets.length] = new specialBullet(player, 2);
        }
        else{
          specialbullets[specialbullets.length] = new specialBullet(player, -2); 
        }
        maxSpecialBullets = maxSpecialBullets - 1;
        specialbulletaccept = false
        setTimeout(acceptspecial, 1000)
        if (maxSpecialBullets <= 0){
          specialReaload = false
          setTimeout(specialshootwaittime, 5000)
        }
      }
    }
    player.move()
    player.exist()
    if (win == false){
      player.badguydamagecheck(badguy)
    }
    meter.draw()
    meter.update()
    bulletmeter()
    specialbulletmeter()
    if (playerdisable == true & win == false & badguymoving == true){
      badguy.xSpeed = (player.xPos / 350) - (badguy.xPos / 350)
      badguy.ySpeed = (player.yPos / 350) - (badguy.yPos / 350)
    }
    else if (badguymoving == false){
      badguy.xSpeed = 0
      badguy.ySpeed = 0
    }
    badguy.procent()
    badguy.move()
    badguy.exist()
    if (playerdisable == false){
      image(losetext, width/2-250, 30, 500, 150)
      textSize(32);
      fill(0, 0, 0);
      text('Time: \n' + second + 's \n' + procent + '% \nHighscore: \n' + highscore + 's', width/2-60, height/2);
      fill(255, 255, 255);
    }
    if (win == true){
      image(wintext, width/2-375, 30, 750, 150)
      textSize(32);
      fill(0, 255, 0);
      text('Time: \n' + second + 's \nHighscore: \n' + highscore + 's', width/2-60, height/2);
      fill(255, 255, 255);
    }
    for (var i = 0; i < bullets.length; i++) {
        if (bullets[i]) {
          bullets[i].move()
          bullets[i].exist()
          badguy.damagecheck(bullets[i])
        }
    }
    for (i = 0; i < specialbullets.length; i++) {
        if (specialbullets[i]) {
          specialbullets[i].move()
          specialbullets[i].exist()
          badguy.specialdamagecheck(specialbullets[i])
        }
    }
    for (i = 0; i < badbullets.length; i++) {
        if (badbullets[i]) {
          badbullets[i].move()
          badbullets[i].exist()
          if (win == false){
          player.damagecheck(badbullets[i])
          }
        }
    }
    for (i = 0; i < skybadbullets.length; i++) {
        if (skybadbullets[i]) {
          skybadbullets[i].move()
          skybadbullets[i].exist()
          if (win == false){
            player.damagecheck(skybadbullets[i])
          }
        }
    }
    for (i = 0; i < wallbadbullets.length; i++) {
        if (wallbadbullets[i]) {
          wallbadbullets[i].move()
          wallbadbullets[i].exist()
          if (win == false){
            player.damagecheck(wallbadbullets[i])
          }
        }
    }
  }
}